package com.cg.banking.main;

import com.cg.banking.beans.Address;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.services.BankingServicesImpl;


public class MainClass {

	public static void main(String[] args) {
		try{
			BankingServicesImpl bankingServices=new BankingServicesImpl();
			int customerId=bankingServices.acceptCustomerDetails("sindhu", "k", "a.com", "rrbb87", "hyd", "telangana", 500090, "ban", "karnataka", 77888);
			System.out.println(customerId);
	//		long accountNo=bankingServices.openAccount(100, "savings", 3000);
	//		System.out.println(accountNo);
		Customer[] customer	=bankingServices.getAllCustomerDetails();
	
		}
		catch(Exception e){
			System.out.println("exception"+e);
		}
	}

	
	}

















/*Customer customer=new Customer();
	customer.setCustomerID(100);
//	Customer customer2 = new Customer(101,8125858858l,99999999l,"sindhu","kalakonda","a.com","sept 17","eu90922");
	System.out.println(customer.getCustomerID());
//	System.out.println(customer2.getCustomerID());

	Address address=new Address();
	address.setCity("Hyderabad");
	System.out.println(address.getCity());

	Account account =new Account();
	account.setAccountNo(812);
	System.out.println(account.getAccountNo());

	Transaction transaction =new Transaction();
	transaction.setTransactionID(800);
	System.out.println(transaction.getTransactionID());
				}*/