package com.cg.banking.beans;

import com.cg.banking.beans.Transaction;

public class Account {
	//	private  int ACCOUNT_IDX_COUNTER=0;
	//	private  int ACCOUNT_ID_COUNTER=1;
	private  int TRANSACTION_IDX_COUNTER=0;
	private  int TRANSACTION_ID_COUNTER=1;

	private int accountNo;
	private float accountBalance;
	private String accountType;
	private String accountStatus;
	private int accountPin;
	private Transaction transaction[]; 
	public Account(){}

	public Account(int accountNo, float accountBalance, String accountType, String accountStatus,
			Transaction[] transaction) {
		super();
		this.accountNo = accountNo;
		this.accountBalance = accountBalance;
		this.accountType = accountType;
		this.accountStatus = accountStatus;
		this.transaction = transaction;
	}

	public Account( String accountType,float accountBalance) {
		super();
		this.accountBalance = accountBalance;
		this.accountType = accountType;
	}
	/*	public int getACCOUNT_IDX_COUNTER() {
		return ACCOUNT_IDX_COUNTER;
	}
	public void setACCOUNT_IDX_COUNTER(int aCCOUNT_IDX_COUNTER) {
		ACCOUNT_IDX_COUNTER = aCCOUNT_IDX_COUNTER;
	}
	public int getACCOUNT_ID_COUNTER() {
		return ACCOUNT_ID_COUNTER;
	}
	public void setACCOUNT_ID_COUNTER(int aCCOUNT_ID_COUNTER) {
		ACCOUNT_ID_COUNTER = aCCOUNT_ID_COUNTER;
	}*/

	public int getTRANSACTION_IDX_COUNTER() {
		return TRANSACTION_IDX_COUNTER;
	}

	public void setTRANSACTION_IDX_COUNTER(int tRANSACTION_IDX_COUNTER) {
		TRANSACTION_IDX_COUNTER = tRANSACTION_IDX_COUNTER;
	}

	public int getTRANSACTION_ID_COUNTER() {
		return TRANSACTION_ID_COUNTER;
	}

	public void setTRANSACTION_ID_COUNTER(int tRANSACTION_ID_COUNTER) {
		TRANSACTION_ID_COUNTER = tRANSACTION_ID_COUNTER;
	}

	public int getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}

	public float getAccountBalance() {
		return accountBalance;
	}

	public void setAccountBalance(float accountBalance) {
		this.accountBalance = accountBalance;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public String getAccountStatus() {
		return accountStatus;
	}

	public void setAccountStatus(String accountStatus) {
		this.accountStatus = accountStatus;
	}

	public int getAccountPin() {
		return accountPin;
	}

	public void setAccountPin(int accountPin) {
		this.accountPin = accountPin;
	}

	public Transaction[] getTransaction() {
		return transaction;
	}

	public void setTransaction(Transaction[] transaction) {
		this.transaction = transaction;
	}


	
}