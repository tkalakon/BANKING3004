package com.cg.banking.beans;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Address;

public class Customer {
	private int ACCOUNT_IDX_COUNTER=0;
	//	private int ACCOUNT_ID_COUNTER=1;
	private int customerID;
	private long mobileNo, aadharNo;
	private String firstName, lastName, emailID, pancardNo;
	private Account account[];
	private Address localaddress,homeaddress;

	public Customer(){}

	public Customer(String firstName, String lastName, String emailID, String pancardNo, Address localaddress,
			Address homeaddress) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.emailID = emailID;
		this.pancardNo = pancardNo;
		this.localaddress = localaddress;
		this.homeaddress = homeaddress;
	}

	public int getACCOUNT_IDX_COUNTER() {
		return ACCOUNT_IDX_COUNTER;
	}

	public void setACCOUNT_IDX_COUNTER(int aCCOUNT_IDX_COUNTER) {
		ACCOUNT_IDX_COUNTER = aCCOUNT_IDX_COUNTER;
	}

	public int getCustomerID() {
		return customerID;
	}

	public void setCustomerID(int customerID) {
		this.customerID = customerID;
	}

	public long getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(long mobileNo) {
		this.mobileNo = mobileNo;
	}

	public long getAadharNo() {
		return aadharNo;
	}

	public void setAadharNo(long aadharNo) {
		this.aadharNo = aadharNo;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmailID() {
		return emailID;
	}

	public void setEmailID(String emailID) {
		this.emailID = emailID;
	}

	public String getPancardNo() {
		return pancardNo;
	}

	public void setPancardNo(String pancardNo) {
		this.pancardNo = pancardNo;
	}

	public Account[] getAccount() {
		return account;
	}

	public void setAccount(Account[] account) {
		this.account = account;
	}

	public Address getLocaladdress() {
		return localaddress;
	}

	public void setLocaladdress(Address localaddress) {
		this.localaddress = localaddress;
	}

	public Address getHomeaddress() {
		return homeaddress;
	}

	public void setHomeaddress(Address homeaddress) {
		this.homeaddress = homeaddress;
	}

}
