package com.cg.banking.services;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Address;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;
import com.cg.banking.daoservices.BankingDAOServicesImpl;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.CustomerNotFoundException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;

public class BankingServicesImpl implements BankingServices {
	BankingDAOServicesImpl daoServices=new BankingDAOServicesImpl(); 

	@Override
	public int acceptCustomerDetails(String firstName, String lastName, String customerEmailId, String panCard,
			String localAddressCity, String localAddressState, int localAddressPinCode, String homeAddressCity,
			String homeAddressState, int homeAddressPinCode) throws BankingServicesDownException {
		return daoServices.insertCustomer(new Customer(firstName,lastName, customerEmailId,panCard, 
				new Address( localAddressPinCode,localAddressCity, localAddressState),
				new Address(homeAddressPinCode,homeAddressCity,homeAddressState)));
	}

	@Override
	public long openAccount(int customerId, String accountType, float initBalance) throws InvalidAmountException,
	CustomerNotFoundException, InvalidAccountTypeException, BankingServicesDownException {
		System.out.println(customerId+accountType+initBalance);
		return daoServices.insertAccount(customerId, new Account(accountType,initBalance));
	}

	@Override
	public Customer getCustomerDetails(int customerId) throws CustomerNotFoundException, BankingServicesDownException {
		return daoServices.getCustomer(customerId);
	}

	@Override
	public Account getAccountDetails(int customerId, long accountNo)
			throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException {
		return daoServices.getAccount(customerId, accountNo);
	}

	@Override
	public Customer[] getAllCustomerDetails() throws BankingServicesDownException {
		return daoServices.getCustomers();
	}

	@Override
	public Account[] getcustomerAllAccountDetails(int customerId)
			throws BankingServicesDownException, CustomerNotFoundException {
		return daoServices.getAccounts(customerId);
	}

	@Override
	public Transaction[] getAccountAllTransaction(int customerId, long accountNo)
			throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException {
		return daoServices.getTransactions(customerId, accountNo);
	}

	@Override
	public int generateNewPin(int customerId, long accountNo)
			throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException {
		Account account=this.getAccountDetails(customerId, accountNo);
		account.setAccountStatus("Active");
		return daoServices.generatePin(customerId, account);
	}

	@Override
	public float depositAmount(int customerId, long accountNo, float amount) throws CustomerNotFoundException,
	AccountNotFoundException, BankingServicesDownException, AccountBlockedException {
		Account account =this.getAccountDetails(customerId, accountNo);
		daoServices.insertTransaction(customerId, accountNo, new Transaction(amount));
		account.setAccountBalance(account.getAccountBalance()+amount);
		return account.getAccountBalance();
	}

	@Override
	public float withdrawAmount(int customerId, long accountNo, float amount, int pinNumber)
			throws InsufficientAmountException, CustomerNotFoundException, AccountNotFoundException,
			InvalidPinNumberException, BankingServicesDownException, AccountBlockedException {
		int pinCounter=0;
		Account account=this.getAccountDetails(customerId, accountNo);
		if(pinNumber==account.getAccountPin()&&pinCounter<3)
			if(account.getAccountBalance()>amount){
				daoServices.insertTransaction(customerId, accountNo, new Transaction(amount));
				account.setAccountBalance(account.getAccountBalance()-amount);
			}
			else
				return account.getAccountBalance();
		else
			pinCounter++;
		if(pinCounter>3)
			account.setAccountStatus("Account Blocked");
		return account.getAccountBalance();
	}

	@Override
	public boolean fundTransfer(int customerIdTo, long accountNoTo, int customerIdFrom, long accountNoFrom,
			float transferAmount, int pinNumber) throws InsufficientAmountException, CustomerNotFoundException,
	AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException {
		int pinCounter=0;
		Account account=this.getAccountDetails(customerIdFrom, accountNoFrom);
		Account account2=this.getAccountDetails(customerIdTo, accountNoTo);
		if(pinNumber==account.getAccountPin()&&pinCounter<3)
			if(account.getAccountBalance()>transferAmount){
				daoServices.insertTransaction(customerIdFrom, accountNoFrom, new Transaction(transferAmount));
				account.setAccountBalance(account.getAccountBalance()-transferAmount);
				daoServices.insertTransaction(customerIdTo, accountNoTo, new Transaction(transferAmount));
				account2.setAccountBalance(account2.getAccountBalance()+transferAmount);
				return true;
			}
			else
				account.setAccountBalance(account.getAccountBalance());
		else
			pinCounter++;
		if(pinCounter>3)
			account.setAccountStatus("Account Blocked");		
		return false;
	}


	@Override
	public boolean changeAccountPin(int customerId, long accountNo, int oldPinNumber, int newPinNumber)
			throws CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException,
			BankingServicesDownException {
		Account account=this.getAccountDetails(customerId, accountNo);
		if(oldPinNumber==account.getAccountPin()){
			account.setAccountPin(newPinNumber);
			return true;
		}
		return false;
	}

	@Override
	public String accountStatus(int customerId, long accountNo) throws BankingServicesDownException,
	CustomerNotFoundException, AccountNotFoundException, AccountBlockedException {
		return daoServices.getAccount(customerId, accountNo).getAccountStatus();
	}

	@Override
	public boolean closeAccount(int customerId, long accountNo)
			throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException {
		Account account=this.getAccountDetails(customerId, accountNo);
		account.setAccountStatus("Inactive");
		return daoServices.deleteAccount(customerId, accountNo);
	}
}
